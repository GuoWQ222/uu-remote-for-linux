# Mutter 46 Wayland modifier-state backport

The native seat and Wayland keyboard in Mutter 46 independently track XKB
locks. If the input method consumes a Caps Lock key event, the seat toggles
but the Wayland event path misses it. Ordinary key events preserve the offset.
This is a compositor consistency problem; a particular IME can trigger it.

Backported from GNOME/mutter commits:
- aeac0f33c2d06ac356af253ed52c175b48999f92: publish all native modifier state.
- 1940c6eba938a9413b93694573501153788d1f0f: abstract keymap state getter.
- 7d0d128e005fb737df7a8eea5e472d6c229898e1: remove duplicate Wayland accounting.
  https://gitlab.gnome.org/GNOME/mutter/-/merge_requests/4546

Adaptations retain the Mutter 46 MetaAnonymousFile name and native keymap
layout. Wayland publishes the backend modifier tuple rather than deriving
locks from the subset of events that survive filtering. The XKB state is
retained only for pressed-key bookkeeping, as in upstream.

Validation must reproduce the consumed-Caps failure before the change and
run the same test after it, including actual text input, IME switching,
reconnection, and session restart. Unit/build success alone is insufficient.

Mutter 46 integration: the native keymap state-changed signal also drives
Wayland modifier notifications. This covers IMEs consuming both Caps events,
without waiting for the next unfiltered key or using a polling/reset daemon.

Event ordering follow-up: backport 0828fd6169c17ca54633f76936f03ac496f6b01e
(GNOME MR 4686). Every key is preceded by its own captured modifier state;
the resulting backend state is sent after key delivery. Updates used solely
for pressed-key bookkeeping do not send protocol events. This prevents
XWayland from toggling a lock after already receiving its resulting state
and prevents later queued modifiers from changing earlier key meanings.
